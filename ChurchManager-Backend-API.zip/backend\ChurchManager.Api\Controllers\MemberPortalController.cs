using System.Security.Claims;
using System.Text.Json;
using ChurchManager.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChurchManager.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/member")]
public sealed class MemberPortalController(AppDbContext db) : ControllerBase
{
    private int? CurrentChurchId =>
        int.TryParse(User.FindFirstValue("church_id"), out var id) ? id : null;

    [HttpGet("events")]
    public async Task<IActionResult> GetEvents(CancellationToken cancellationToken)
    {
        if (CurrentChurchId is not int churchId) return Unauthorized();

        var events = await db.Events.AsNoTracking()
            .Where(x => x.ChurchId == churchId && !x.IsRestricted)
            .OrderBy(x => x.StartsAt)
            .ToListAsync(cancellationToken);

        return Ok(events.Select(x => new
        {
            id = x.Id,
            title = x.Title,
            description = x.Description,
            date = x.StartsAt.ToString("yyyy-MM-dd"),
            time = x.StartsAt.ToString("HH:mm"),
            location = x.Location,
            ministry = x.Ministry,
            status = x.Status
        }));
    }

    [HttpGet("scales")]
    public async Task<IActionResult> GetScales(CancellationToken cancellationToken)
    {
        if (CurrentChurchId is not int churchId) return Unauthorized();

        var currentEmail = (User.FindFirstValue(ClaimTypes.Email) ?? string.Empty).Trim().ToLowerInvariant();
        var currentName = (User.FindFirstValue(ClaimTypes.Name) ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(currentName) && string.IsNullOrWhiteSpace(currentEmail))
            return Unauthorized();

        // Vínculo seguro com o cadastro em Members da mesma igreja
        var memberRecord = await db.Members.AsNoTracking()
            .FirstOrDefaultAsync(m => m.ChurchId == churchId && !string.IsNullOrEmpty(currentEmail) && m.Email.ToLower() == currentEmail, cancellationToken)
            ?? await db.Members.AsNoTracking()
            .FirstOrDefaultAsync(m => m.ChurchId == churchId && m.Name.ToUpper() == currentName.ToUpper(), cancellationToken);

        // Conjunto de identificadores válidos para matching de participante na escala
        var validIdentifiers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!string.IsNullOrWhiteSpace(currentName)) validIdentifiers.Add(currentName);
        if (!string.IsNullOrWhiteSpace(currentEmail)) validIdentifiers.Add(currentEmail);
        if (memberRecord != null)
        {
            if (!string.IsNullOrWhiteSpace(memberRecord.Name)) validIdentifiers.Add(memberRecord.Name);
            if (!string.IsNullOrWhiteSpace(memberRecord.Email)) validIdentifiers.Add(memberRecord.Email);
            validIdentifiers.Add(memberRecord.Id.ToString());
        }

        var scales = await db.Scales.AsNoTracking()
            .Where(x => x.ChurchId == churchId)
            .OrderBy(x => x.StartsAt)
            .ToListAsync(cancellationToken);

        return Ok(scales
            .Select(x => new { Scale = x, Members = ParseMembers(x.AssignedMembersJson) })
            .Where(x => x.Members.Any(assigned => validIdentifiers.Contains(assigned.Trim())
                || validIdentifiers.Any(id => assigned.Trim().IndexOf(id, StringComparison.OrdinalIgnoreCase) >= 0)))
            .Select(x => new
            {
                id = x.Scale.Id,
                title = x.Scale.Title,
                ministry = x.Scale.Ministry,
                date = x.Scale.StartsAt.ToString("yyyy-MM-dd"),
                time = x.Scale.StartsAt.ToString("HH:mm"),
                status = x.Scale.Status,
                members = string.Join(", ", x.Members)
            }));
    }

    [HttpGet("profile")]
    [HttpGet("me")]
    public async Task<IActionResult> GetProfile(CancellationToken cancellationToken)
    {
        if (CurrentChurchId is not int churchId) return Unauthorized();

        var currentEmail = (User.FindFirstValue(ClaimTypes.Email) ?? string.Empty).Trim().ToLowerInvariant();
        var currentName = (User.FindFirstValue(ClaimTypes.Name) ?? string.Empty).Trim();
        var currentRole = User.FindFirstValue(ClaimTypes.Role) ?? "Membro";

        var member = await db.Members.AsNoTracking()
            .FirstOrDefaultAsync(m => m.ChurchId == churchId && !string.IsNullOrEmpty(currentEmail) && m.Email.ToLower() == currentEmail, cancellationToken)
            ?? await db.Members.AsNoTracking()
            .FirstOrDefaultAsync(m => m.ChurchId == churchId && m.Name.ToUpper() == currentName.ToUpper(), cancellationToken);

        return Ok(new
        {
            name = member?.Name ?? currentName,
            email = member?.Email ?? currentEmail,
            phone = member?.Phone ?? "",
            ministry = member?.Ministry ?? "",
            role = member?.Role ?? currentRole,
            status = member?.Status ?? "Ativo"
        });
    }

    [HttpGet("settings")]
    public async Task<IActionResult> GetSettings(CancellationToken cancellationToken)
    {
        if (CurrentChurchId is not int churchId) return Unauthorized();

        var church = await db.Churches.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == churchId, cancellationToken);

        return church is null
            ? NotFound()
            : Ok(new
            {
                churchName = church.Name,
                email = church.Email,
                phone = church.Phone,
                address = church.Address
            });
    }

    private static List<string> ParseMembers(string? json)
    {
        try
        {
            return JsonSerializer.Deserialize<List<string>>(string.IsNullOrWhiteSpace(json) ? "[]" : json)
                ?? new List<string>();
        }
        catch (JsonException)
        {
            return new List<string>();
        }
    }
}
