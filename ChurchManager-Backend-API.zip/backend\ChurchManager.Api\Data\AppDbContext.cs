using ChurchManager.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace ChurchManager.Api.Data;

public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Church> Churches => Set<Church>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Member> Members => Set<Member>();
    public DbSet<Ministry> Ministries => Set<Ministry>();
    public DbSet<ChurchEvent> Events => Set<ChurchEvent>();
    public DbSet<FinanceTransaction> Transactions => Set<FinanceTransaction>();
    public DbSet<ChurchRole> Roles => Set<ChurchRole>();
    public DbSet<ChurchScale> Scales => Set<ChurchScale>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // --- PostgreSQL é o único provedor da versão final ---
        // Nomes de tabela e colunas em PascalCase com aspas, coerentes com o schema existente.

        modelBuilder.Entity<Church>(entity =>
        {
            entity.ToTable("Churches");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Name).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Email).HasMaxLength(254).IsRequired();
            entity.Property(x => x.Phone).HasMaxLength(40).IsRequired().HasDefaultValue("");
            entity.Property(x => x.Address).HasMaxLength(255).IsRequired().HasDefaultValue("");
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.Email).HasDatabaseName("IX_Churches_Email");
        });

        modelBuilder.Entity<AppUser>(entity =>
        {
            entity.ToTable("Users");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Name).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Email).HasMaxLength(254).IsRequired();
            entity.Property(x => x.PasswordHash).HasMaxLength(512).IsRequired();
            entity.Property(x => x.Role).HasMaxLength(80).IsRequired().HasDefaultValue("Membro");
            entity.Property(x => x.IsActive).HasDefaultValue(true);
            entity.Property(x => x.CargoId).HasDefaultValue(0);
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.Email).IsUnique().HasDatabaseName("IX_Users_Email");
            entity.HasIndex(x => x.ChurchId).HasDatabaseName("IX_Users_ChurchId");
            entity.HasOne<Church>().WithMany().HasForeignKey(x => x.ChurchId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<ChurchRole>().WithMany().HasForeignKey(x => x.CargoId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Member>(entity =>
        {
            entity.ToTable("Members");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Name).HasMaxLength(160).IsRequired();
            entity.Property(x => x.Email).HasMaxLength(254).IsRequired().HasDefaultValue("");
            entity.Property(x => x.Phone).HasMaxLength(40).IsRequired().HasDefaultValue("");
            entity.Property(x => x.Ministry).HasMaxLength(120).IsRequired().HasDefaultValue("");
            entity.Property(x => x.Status).HasMaxLength(40).IsRequired().HasDefaultValue("Ativo");
            entity.Property(x => x.Role).HasMaxLength(80).IsRequired().HasDefaultValue("Membro");
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.ChurchId).HasDatabaseName("IX_Members_ChurchId");
            entity.HasOne<Church>().WithMany().HasForeignKey(x => x.ChurchId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Ministry>(entity =>
        {
            entity.ToTable("Ministries");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Name).HasMaxLength(160).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(500).IsRequired().HasDefaultValue("");
            entity.Property(x => x.Coordinator).HasMaxLength(160).IsRequired().HasDefaultValue("");
            entity.Property(x => x.Status).HasMaxLength(40).IsRequired().HasDefaultValue("Ativo");
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.ChurchId).HasDatabaseName("IX_Ministries_ChurchId");
            entity.HasOne<Church>().WithMany().HasForeignKey(x => x.ChurchId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ChurchEvent>(entity =>
        {
            entity.ToTable("Events");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Title).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Description).IsRequired().HasDefaultValue("");
            entity.Property(x => x.StartsAt).HasColumnType("timestamp with time zone");
            entity.Property(x => x.Location).HasMaxLength(255).IsRequired().HasDefaultValue("");
            entity.Property(x => x.Ministry).HasMaxLength(120).IsRequired().HasDefaultValue("Todos");
            entity.Property(x => x.Status).HasMaxLength(40).IsRequired().HasDefaultValue("Planejado");
            entity.Property(x => x.IsRestricted).HasDefaultValue(false);
            entity.Property(x => x.RecurrenceType).HasMaxLength(50).IsRequired().HasDefaultValue("Nenhuma");
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.ChurchId).HasDatabaseName("IX_Events_ChurchId");
            entity.HasIndex(x => new { x.ChurchId, x.StartsAt }).HasDatabaseName("IX_Events_ChurchId_StartsAt");
            entity.HasOne<Church>().WithMany().HasForeignKey(x => x.ChurchId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<FinanceTransaction>(entity =>
        {
            entity.ToTable("Transactions");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Description).HasMaxLength(180).IsRequired();
            entity.Property(x => x.Category).HasMaxLength(100).IsRequired().HasDefaultValue("Outros");
            entity.Property(x => x.Amount).HasPrecision(12, 2);
            entity.Property(x => x.TransactionType).HasMaxLength(30).IsRequired().HasDefaultValue("Income");
            entity.Property(x => x.TransactionDate).HasColumnType("timestamp with time zone");
            entity.Property(x => x.Method).HasMaxLength(50).IsRequired().HasDefaultValue("PIX");
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.ChurchId).HasDatabaseName("IX_Transactions_ChurchId");
            entity.HasIndex(x => new { x.ChurchId, x.TransactionDate }).HasDatabaseName("IX_Transactions_ChurchId_TransactionDate");
            entity.HasOne<Church>().WithMany().HasForeignKey(x => x.ChurchId).OnDelete(DeleteBehavior.Cascade);
            // Constraints de valor e tipo no banco
            entity.ToTable(t => t.HasCheckConstraint("CK_Transactions_Amount", "\"Amount\" > 0"));
            entity.ToTable(t => t.HasCheckConstraint("CK_Transactions_Type", "\"TransactionType\" IN ('Income','Expense')"));
        });

        modelBuilder.Entity<ChurchRole>(entity =>
        {
            entity.ToTable("Roles");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Name).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(500).IsRequired().HasDefaultValue("");
            entity.Property(x => x.PermissionsJson).HasColumnType("text").IsRequired().HasDefaultValue("[]");
            entity.Property(x => x.Users).HasDefaultValue(0);
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.ChurchId).HasDatabaseName("IX_Roles_ChurchId");
            entity.HasOne<Church>().WithMany().HasForeignKey(x => x.ChurchId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ChurchScale>(entity =>
        {
            entity.ToTable("Scales");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Id).UseIdentityByDefaultColumn();
            entity.Property(x => x.Title).HasMaxLength(180).IsRequired();
            entity.Property(x => x.Ministry).HasMaxLength(120).IsRequired();
            entity.Property(x => x.StartsAt).HasColumnType("timestamp with time zone");
            entity.Property(x => x.AssignedMembersJson).HasColumnType("text").IsRequired().HasDefaultValue("[]");
            entity.Property(x => x.Status).HasMaxLength(40).IsRequired().HasDefaultValue("Pendente");
            entity.Property(x => x.EventId);
            entity.Property(x => x.LegacyMinistryName).HasMaxLength(100).IsRequired().HasDefaultValue("");
            entity.Property(x => x.CreatedAt).HasColumnType("timestamp with time zone").HasDefaultValueSql("CURRENT_TIMESTAMP");
            entity.HasIndex(x => x.ChurchId).HasDatabaseName("IX_Scales_ChurchId");
            entity.HasIndex(x => new { x.ChurchId, x.StartsAt }).HasDatabaseName("IX_Scales_ChurchId_StartsAt");
            entity.HasOne<Church>().WithMany().HasForeignKey(x => x.ChurchId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne<ChurchEvent>().WithMany().HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.SetNull);
        });
    }
}
